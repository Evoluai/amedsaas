
import React, { useState, useEffect } from "react";
import { initializeApp } from "firebase/app";
import { getFirestore, collection, getDocs, addDoc } from "firebase/firestore";
import { getAuth, onAuthStateChanged, signInWithEmailAndPassword, signOut } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyB5P9fmcr2yuUW6ha92I_6TCU_ZGymCoc4",
  authDomain: "amedsaas.firebaseapp.com",
  projectId: "amedsaas",
  storageBucket: "amedsaas.firebasestorage.app",
  messagingSenderId: "954049675224",
  appId: "1:954049675224:web:abcebf9fb06fdf274b7cad",
  measurementId: "G-94YDBN7PXK"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

export default function App() {
  const [user, setUser] = useState(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [empresas, setEmpresas] = useState([]);
  const [form, setForm] = useState({ razao_social: "", cnpj: "", email: "", status: "Ativo" });

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, setUser);
    return () => unsubscribe();
  }, []);

  const login = async () => {
    await signInWithEmailAndPassword(auth, email, password);
  };

  const logout = async () => {
    await signOut(auth);
  };

  const fetchEmpresas = async () => {
    const snapshot = await getDocs(collection(db, "empresas"));
    const lista = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    setEmpresas(lista);
  };

  const addEmpresa = async (e) => {
    e.preventDefault();
    const data = { ...form, data_cadastro: new Date().toISOString() };
    await addDoc(collection(db, "empresas"), data);
    setForm({ razao_social: "", cnpj: "", email: "", status: "Ativo" });
    fetchEmpresas();
  };

  useEffect(() => {
    if (user) fetchEmpresas();
  }, [user]);

  if (!user) return (
    <div style={{ padding: 20 }}>
      <h1>Login Admin SAS</h1>
      <input placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} />
      <br />
      <input type="password" placeholder="Senha" value={password} onChange={e => setPassword(e.target.value)} />
      <br />
      <button onClick={login}>Entrar</button>
    </div>
  );

  return (
    <div style={{ padding: 20 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
        <h2>Painel Admin SAS</h2>
        <button onClick={logout}>Sair</button>
      </div>

      <form onSubmit={addEmpresa}>
        <h3>Cadastrar Nova Empresa</h3>
        <input placeholder="Razão Social" value={form.razao_social} onChange={e => setForm({ ...form, razao_social: e.target.value })} required />
        <input placeholder="CNPJ" value={form.cnpj} onChange={e => setForm({ ...form, cnpj: e.target.value })} required />
        <input placeholder="Email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} required />
        <input placeholder="Status" value={form.status} onChange={e => setForm({ ...form, status: e.target.value })} />
        <button type="submit">Salvar</button>
      </form>

      <table border="1" cellPadding="5" style={{ marginTop: 20 }}>
        <thead>
          <tr>
            <th>Razão Social</th>
            <th>CNPJ</th>
            <th>Email</th>
            <th>Status</th>
            <th>Cadastro</th>
          </tr>
        </thead>
        <tbody>
          {empresas.map(emp => (
            <tr key={emp.id}>
              <td>{emp.razao_social}</td>
              <td>{emp.cnpj}</td>
              <td>{emp.email}</td>
              <td>{emp.status}</td>
              <td>{new Date(emp.data_cadastro).toLocaleDateString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
